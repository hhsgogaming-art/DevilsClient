Optional locally supplied Fabric mods go here as .jar files.
Only add files you trust and verify that they are for Minecraft 1.21.11 and Fabric.
Sodium duplicates are skipped because the builder resolves Sodium from Modrinth.
