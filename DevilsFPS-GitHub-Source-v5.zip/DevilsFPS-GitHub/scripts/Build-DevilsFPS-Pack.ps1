param(
  [ValidateSet('TryAnotherWay','DevilsFPS')]
  [string]$Profile = 'TryAnotherWay'
)
$ErrorActionPreference = 'Stop'
$OutDir = Join-Path $PSScriptRoot 'output'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$Api = 'https://api.modrinth.com/v2'
$Game = '1.21.11'
if ($Profile -eq 'TryAnotherWay') {
  $PackName = "TryAnotherWay's Mods"
  # Requested mods and required libraries. Only versions that declare Fabric + MC 1.21.11 are included.
  $Projects = @(
    'sodium', 'sodium-extra', 'status-effect-timer', 'supermartijn642s-config-lib',
    'placeholder-api', 'tier-tagger', 'tiers', 'totemcounter', 'ui-utils',
    'ukus-armor-hud', 'ukulib', 'variants-cit', 'view-model', 'walksylib',
    'xaeros-minimap', 'xaeros-world-map',
    # Extra performance and shared API dependencies commonly needed by Fabric mods
    'fabric-api', 'lithium', 'ferrite-core', 'immediatelyfast', 'entityculling', 'dynamic-fps', 'modmenu'
  )
  $ResourcePacks = @('white-and-black-world')
} else {
  $PackName = 'DevilsFPS Competitive'
  $Projects = @('sodium','lithium','ferrite-core','immediatelyfast','entityculling','dynamic-fps','fabric-api','modmenu','zoomify','betterf3','appleskin')
  $ResourcePacks = @()
}
Write-Host "Building $PackName for Minecraft $Game..." -ForegroundColor Cyan
$Files = [System.Collections.Generic.List[object]]::new()
$Included = [System.Collections.Generic.List[string]]::new()
$Skipped = [System.Collections.Generic.List[string]]::new()
foreach ($slug in $Projects) {
  try {
    $uri = "$Api/project/$slug/version?game_versions=%5B%221.21.11%22%5D&loaders=%5B%22fabric%22%5D"
    $versions = Invoke-RestMethod -Uri $uri -TimeoutSec 25
    $v = $versions | Where-Object { $_.version_type -eq 'release' } | Select-Object -First 1
    if (-not $v) { $v = $versions | Select-Object -First 1 }
    if (-not $v) { $Skipped.Add("$slug (no compatible Fabric release listed for $Game)"); Write-Warning "Skipping $slug: no compatible Fabric release listed for $Game"; continue }
    $f = $v.files | Where-Object { $_.primary } | Select-Object -First 1
    if (-not $f) { $f = $v.files | Select-Object -First 1 }
    if (-not $f -or -not $f.hashes.sha1) { $Skipped.Add("$slug (no downloadable file/hash)"); Write-Warning "Skipping $slug: no downloadable file/hash"; continue }
    $Files.Add(@{path="mods/$($f.filename)"; hashes=@{sha1=$f.hashes.sha1}; env=@{client='required'; server='unsupported'}; downloads=@($f.url); fileSize=[long]$f.size})
    $Included.Add("$slug ($($v.version_number))")
    Write-Host " + $slug $($v.version_number)"
  } catch { $Skipped.Add("$slug (query failed)"); Write-Warning "Could not query $slug: $($_.Exception.Message)" }
}
# Resource packs use Modrinth's resource-pack loader tag. Unknown user-uploaded ZIPs cannot be fetched without their original URL.
$ResourcePackFiles = [System.Collections.Generic.List[object]]::new()
foreach ($slug in $ResourcePacks) {
  try {
    $uri = "$Api/project/$slug/version?game_versions=%5B%221.21.11%22%5D&loaders=%5B%22minecraft%22%5D"
    $versions = Invoke-RestMethod -Uri $uri -TimeoutSec 25
    $v = $versions | Where-Object { $_.version_type -eq 'release' } | Select-Object -First 1
    if (-not $v) { $v = $versions | Select-Object -First 1 }
    if (-not $v) { $Skipped.Add("resource pack $slug (not found/compatible)"); continue }
    $f = $v.files | Where-Object { $_.primary } | Select-Object -First 1
    if (-not $f) { $f = $v.files | Select-Object -First 1 }
    if (-not $f -or -not $f.hashes.sha1) { $Skipped.Add("resource pack $slug (no file/hash)"); continue }
    $ResourcePackFiles.Add(@{path="resourcepacks/$($f.filename)"; hashes=@{sha1=$f.hashes.sha1}; env=@{client='optional'; server='unsupported'}; downloads=@($f.url); fileSize=[long]$f.size})
    $Included.Add("resource pack $slug ($($v.version_number))")
  } catch { $Skipped.Add("resource pack $slug (query failed)"); Write-Warning "Could not query resource pack $slug: $($_.Exception.Message)" }
}
foreach ($f in $ResourcePackFiles) { $Files.Add($f) }
if ($Files.Count -lt 3) { throw 'Too few compatible files were found. Check your internet connection and run again.' }
$loader = Invoke-RestMethod -Uri "https://meta.fabricmc.net/v2/versions/loader/$Game" -TimeoutSec 25
$stable = $loader | Where-Object { $_.loader.stable -eq $true } | Select-Object -First 1
if (-not $stable) { throw "No stable Fabric loader was found for Minecraft $Game." }
$versionId = if ($Profile -eq 'TryAnotherWay') { 'TryAnotherWay-1.21.11' } else { 'DevilsFPS-1.21.11' }
$manifest = @{
  formatVersion = 1
  game = 'minecraft'
  versionId = $versionId
  name = $PackName
  summary = 'Fabric PvP client profile. Compatible files are resolved from Modrinth at build time; see README for skipped files.'
  files = @($Files.ToArray())
  dependencies = @{ minecraft = $Game; 'fabric-loader' = $stable.loader.version }
}
$manifestPath = Join-Path $OutDir 'modrinth.index.json'
[System.IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json -Depth 12), [System.Text.UTF8Encoding]::new($false))
$overrides = Join-Path $OutDir 'overrides'
New-Item -ItemType Directory -Force -Path $overrides | Out-Null
# Optional locally supplied files: place public/user-owned JARs and resource-pack ZIPs in these folders.
$localMods = Join-Path $PSScriptRoot 'local-mods'
$localPacks = Join-Path $PSScriptRoot 'local-resourcepacks'
$overrideMods = Join-Path $overrides 'mods'
$overridePacks = Join-Path $overrides 'resourcepacks'
New-Item -ItemType Directory -Force -Path $localMods, $localPacks, $overrideMods, $overridePacks | Out-Null
foreach ($localFile in (Get-ChildItem -LiteralPath $localMods -File -Filter '*.jar' -ErrorAction SilentlyContinue)) {
  # Sodium is already resolved from the official project above; avoid accidentally bundling a second copy.
  if ($localFile.Name -match '^sodium(\.|-)') { Write-Warning "Skipping duplicate local Sodium file: $($localFile.Name)"; continue }
  Copy-Item -LiteralPath $localFile.FullName -Destination (Join-Path $overrideMods $localFile.Name) -Force
  $Included.Add("local mod $($localFile.Name)")
}
# Include the compiled DevilsFPS HUD when this script ships inside the launcher ZIP,
# or when running from the source repository after the hud-mod Gradle build.
$hudCandidates = @(
  (Join-Path (Split-Path $PSScriptRoot -Parent) 'mods'),
  (Join-Path (Split-Path $PSScriptRoot -Parent) 'hud-mod/build/libs')
)
foreach ($hudDir in $hudCandidates) {
  if (Test-Path $hudDir) {
    foreach ($hudJar in (Get-ChildItem -LiteralPath $hudDir -File -Filter 'devilsfps-hud-*.jar' -ErrorAction SilentlyContinue)) {
      Copy-Item -LiteralPath $hudJar.FullName -Destination (Join-Path $overrideMods $hudJar.Name) -Force
      $Included.Add("DevilsFPS HUD module $($hudJar.Name)")
      break
    }
  }
}
foreach ($localFile in (Get-ChildItem -LiteralPath $localPacks -File -Filter '*.zip' -ErrorAction SilentlyContinue)) {
  if ($localFile.Name -match 'xray') { Write-Warning "Skipping Xray resource pack for the fair-play PvP profile: $($localFile.Name)"; continue }
  Copy-Item -LiteralPath $localFile.FullName -Destination (Join-Path $overridePacks $localFile.Name) -Force
  $Included.Add("local resource pack $($localFile.Name)")
}
@"
$PackName
Minecraft: Java $Game / Fabric

Included files:
$($Included -join "`n")

Not included / unavailable:
$($Skipped -join "`n")

The builder only includes files that Modrinth reports as compatible with Minecraft $Game and Fabric. User-uploaded files without a public project URL are not guessed or fabricated.
Xray Ultimate resource packs are intentionally not bundled in this fair-play PvP profile.
"@ | Set-Content -Encoding utf8 (Join-Path $overrides 'PROFILE-README.txt')
# Seed video options for the selected profile. Launcher can also apply them to an existing Prism instance.
$simDistance = if ($Profile -eq 'TryAnotherWay') { 5 } else { 4 }
$fpsLimit = if ($Profile -eq 'TryAnotherWay') { 260 } else { 200 }
$options = @(
  'renderDistance:6', "simulationDistance:$simDistance", "maxFps:$fpsLimit", 'enableVsync:false', 'fullscreen:false',
  'gamma:1.0', 'entityDistanceScaling:0.5', 'clouds:0', 'particles:2', 'graphicsMode:0'
)
[System.IO.File]::WriteAllLines((Join-Path $overrides 'options.txt'), [string[]]$options, [System.Text.UTF8Encoding]::new($false))
$pack = Join-Path $OutDir "$($Profile)-Minecraft-1.21.11.mrpack"
if (Test-Path $pack) { Remove-Item $pack -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($pack, [System.IO.Compression.ZipArchiveMode]::Create)
try {
  [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $manifestPath, 'modrinth.index.json') | Out-Null
  $readme = Join-Path $PSScriptRoot 'README.txt'
  [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $readme, 'README.txt') | Out-Null
  foreach ($overrideFile in (Get-ChildItem -LiteralPath $overrides -File -Recurse)) {
    $relative = [System.IO.Path]::GetRelativePath($overrides, $overrideFile.FullName).Replace('\', '/')
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $overrideFile.FullName, "overrides/$relative") | Out-Null
  }
} finally { $zip.Dispose() }
Write-Host "`nCreated: $pack" -ForegroundColor Green
Write-Host "`nIncluded files:" -ForegroundColor Cyan
$Included | ForEach-Object { Write-Host " - $_" }
if ($Skipped.Count -gt 0) { Write-Host "`nSkipped (check compatibility or provide original project URLs):" -ForegroundColor Yellow; $Skipped | ForEach-Object { Write-Host " - $_" } }
Write-Host "`nNext: in Prism Launcher choose Add Instance > Import and select this .mrpack file."
