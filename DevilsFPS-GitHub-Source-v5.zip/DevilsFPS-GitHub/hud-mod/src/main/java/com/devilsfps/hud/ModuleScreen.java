package com.devilsfps.hud;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public final class ModuleScreen extends Screen {
    private final List<Button> toggles = new ArrayList<>();
    private int scale = DevilsFpsHud.settings.scale;
    private boolean draggingHud;
    private double dragOffsetX;
    private double dragOffsetY;
    public ModuleScreen() { super(Component.literal("DevilsFPS Modules")); }

    @Override protected void init() {
        toggles.clear();
        int left = this.width / 2 - 245;
        int right = this.width / 2 - 15;
        int topLeft = 56;
        int topRight = 56;
        addToggle("FPS", () -> DevilsFpsHud.settings.fps, v -> DevilsFpsHud.settings.fps = v, left, topLeft); topLeft += 25;
        addToggle("Own Ping", () -> DevilsFpsHud.settings.ping, v -> DevilsFpsHud.settings.ping = v, left, topLeft); topLeft += 25;
        addToggle("Server Address", () -> DevilsFpsHud.settings.serverAddress, v -> DevilsFpsHud.settings.serverAddress = v, left, topLeft); topLeft += 25;
        addToggle("Coordinates", () -> DevilsFpsHud.settings.coordinates, v -> DevilsFpsHud.settings.coordinates = v, left, topLeft); topLeft += 25;
        addToggle("Keystrokes", () -> DevilsFpsHud.settings.keystrokes, v -> DevilsFpsHud.settings.keystrokes = v, left, topLeft); topLeft += 25;
        addToggle("CPS", () -> DevilsFpsHud.settings.showCps, v -> DevilsFpsHud.settings.showCps = v, left, topLeft); topLeft += 25;
        addToggle("Armor Status", () -> DevilsFpsHud.settings.armor, v -> DevilsFpsHud.settings.armor = v, left, topLeft); topLeft += 25;
        addToggle("Held Item", () -> DevilsFpsHud.settings.heldItem, v -> DevilsFpsHud.settings.heldItem = v, left, topLeft); topLeft += 25;
        addToggle("Item Durability", () -> DevilsFpsHud.settings.itemDurability, v -> DevilsFpsHud.settings.itemDurability = v, left, topLeft);
        topLeft += 25;
        addToggle("Inventory HUD+ Preview", () -> DevilsFpsHud.settings.inventoryHud, v -> DevilsFpsHud.settings.inventoryHud = v, left, topLeft);

        addToggle("Potion Effects", () -> DevilsFpsHud.settings.potionEffects, v -> DevilsFpsHud.settings.potionEffects = v, right, topRight); topRight += 25;
        addToggle("Sprint Status", () -> DevilsFpsHud.settings.sprint, v -> DevilsFpsHud.settings.sprint = v, right, topRight); topRight += 25;
        addToggle("Health", () -> DevilsFpsHud.settings.health, v -> DevilsFpsHud.settings.health = v, right, topRight); topRight += 25;
        addToggle("Hunger", () -> DevilsFpsHud.settings.hunger, v -> DevilsFpsHud.settings.hunger = v, right, topRight); topRight += 25;
        addToggle("Facing / Direction", () -> DevilsFpsHud.settings.direction, v -> DevilsFpsHud.settings.direction = v, right, topRight); topRight += 25;
        addToggle("Biome", () -> DevilsFpsHud.settings.biome, v -> DevilsFpsHud.settings.biome = v, right, topRight); topRight += 25;
        addToggle("World Time", () -> DevilsFpsHud.settings.worldTime, v -> DevilsFpsHud.settings.worldTime = v, right, topRight); topRight += 25;
        addToggle("Movement Speed", () -> DevilsFpsHud.settings.speed, v -> DevilsFpsHud.settings.speed = v, right, topRight); topRight += 25;
        addToggle("TPS (server support required)", () -> DevilsFpsHud.settings.tpsEstimate, v -> DevilsFpsHud.settings.tpsEstimate = v, right, topRight);
        addRenderableWidget(Button.builder(Component.literal("HUD size −"), b -> { scale = Math.max(50, scale - 10); DevilsFpsHud.settings.scale = scale; DevilsFpsHud.settings.save(); }).bounds(left, this.height - 40, 95, 20).build());
        addRenderableWidget(Button.builder(Component.literal("HUD size +"), b -> { scale = Math.min(150, scale + 10); DevilsFpsHud.settings.scale = scale; DevilsFpsHud.settings.save(); }).bounds(left + 100, this.height - 40, 95, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset position"), b -> { DevilsFpsHud.settings.hudX = 6; DevilsFpsHud.settings.hudY = 6; DevilsFpsHud.settings.save(); }).bounds(left + 200, this.height - 40, 120, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> { DevilsFpsHud.settings.save(); onClose(); }).bounds(right + 15, this.height - 40, 100, 20).build());
    }

    private void addToggle(String label, java.util.function.Supplier<Boolean> get, java.util.function.Consumer<Boolean> set, int x, int y) {
        Button button = Button.builder(Component.literal(label + ": " + (get.get() ? "ON" : "OFF")), b -> {
            boolean next = !get.get(); set.accept(next); b.setMessage(Component.literal(label + ": " + (next ? "ON" : "OFF"))); DevilsFpsHud.settings.save();
        }).bounds(x, y, 210, 20).build();
        toggles.add(button); addRenderableWidget(button);
    }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(0, 0, width, height, 0xE9101118);
        graphics.drawCenteredString(font, Component.literal("DEVILSFPS  /  HUD MODULES"), width / 2, 20, 0xFFFF415F);
        graphics.drawCenteredString(font, Component.literal("Right Shift opens this menu · click modules to toggle · settings save automatically"), width / 2, 36, 0xFFB7BBC7);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
