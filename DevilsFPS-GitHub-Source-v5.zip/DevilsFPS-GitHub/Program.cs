using System.Diagnostics;
using System.Drawing;
using System.Text.Json;
using System.Windows.Forms;

namespace DevilsFPS;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new LauncherForm());
    }
}

internal sealed class Settings
{
    public int Ram { get; set; } = 3072;
    public int MinRam { get; set; } = 512;
    public int RenderDistance { get; set; } = 6;
    public int SimulationDistance { get; set; } = 5;
    public int FpsCap { get; set; } = 260;
    public string Resolution { get; set; } = "Native";
    public bool Fullscreen { get; set; }
    public string Graphics { get; set; } = "Fast";
    public string Particles { get; set; } = "Minimal";
    public string Clouds { get; set; } = "Off";
    public int EntityDistance { get; set; } = 50;
    public double Brightness { get; set; } = 1.0;
    public bool Vsync { get; set; }
    public string ExtraJavaArgs { get; set; } = "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=50";
}

internal sealed record ModpackProfile(string Id, string DisplayName, string Description, string InstanceName);

internal sealed class LauncherForm : Form
{
    private static readonly Color Bg = Color.FromArgb(13, 15, 21);
    private static readonly Color Panel = Color.FromArgb(23, 26, 35);
    private static readonly Color Panel2 = Color.FromArgb(31, 35, 46);
    private static readonly Color Accent = Color.FromArgb(255, 65, 95);
    private static readonly Color Muted = Color.FromArgb(164, 170, 185);
    private string SettingsPath => Path.Combine(AppContext.BaseDirectory, $"DevilsFPS-settings-{selectedProfile.Id}.json");
    private readonly List<ModpackProfile> profiles = new()
    {
        new("TryAnotherWay", "TryAnotherWay's Mods", "PvP HUD, status timers, waypoints and low-effects video settings.", "TryAnotherWay-1.21.11"),
        new("DevilsFPS", "DevilsFPS Competitive", "Lightweight performance-first Fabric profile.", "DevilsFPS-1.21.11")
    };
    private Settings settings = new();
    private ModpackProfile selectedProfile;
    private readonly NumericUpDown ram = Num(1024, 6144, 3072);
    private readonly NumericUpDown minRam = Num(256, 2048, 512);
    private readonly NumericUpDown render = Num(2, 16, 6);
    private readonly NumericUpDown sim = Num(2, 12, 5);
    private readonly NumericUpDown entity = Num(25, 100, 50);
    private readonly NumericUpDown brightness = Num(0, 100, 100);
    private readonly ComboBox fps = Combo("Unlimited", "60", "75", "120", "144", "165", "200", "240");
    private readonly ComboBox resolution = Combo("Native", "1280x720", "1366x768", "1600x900", "1920x1080");
    private readonly ComboBox graphics = Combo("Fast", "Fancy");
    private readonly ComboBox particles = Combo("Minimal", "Decreased", "All");
    private readonly ComboBox clouds = Combo("Off", "Fast", "Fancy");
    private readonly CheckBox fullscreen = new() { Text = "Fullscreen", Checked = false, AutoSize = true };
    private readonly CheckBox vsync = new() { Text = "VSync", Checked = false, AutoSize = true };
    private readonly TextBox javaArgs = new() { Multiline = true, Height = 56, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill };
    private readonly Label status = new() { AutoSize = true, ForeColor = Muted, Text = "Ready · Select a modpack, then build/import it in Prism Launcher." };
    private readonly Label playProfile = new() { AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 19, FontStyle.Bold) };
    private readonly Label playDescription = new() { AutoSize = true, ForeColor = Muted, MaximumSize = new Size(560, 0) };
    private readonly Label packProfile = new() { AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI", 19, FontStyle.Bold) };
    private readonly Label packDescription = new() { AutoSize = true, ForeColor = Muted, MaximumSize = new Size(560, 0) };
    private readonly Label modsSummary = new() { AutoSize = true, ForeColor = Muted, MaximumSize = new Size(620, 0) };
    private readonly ComboBox profilePicker = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 300, IntegralHeight = false, DropDownHeight = 180 };
    private readonly ListBox profileList = new() { Dock = DockStyle.Fill, BorderStyle = BorderStyle.None, IntegralHeight = false };
    private readonly TabControl pages = new() { Dock = DockStyle.Fill, Appearance = TabAppearance.FlatButtons, ItemSize = new Size(0, 1), SizeMode = TabSizeMode.Fixed };

    public LauncherForm()
    {
        selectedProfile = profiles[0];
        Text = "DevilsFPS Client";
        MinimumSize = new Size(980, 680); Size = new Size(1120, 760);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Bg; ForeColor = Color.White;
        Font = new Font("Segoe UI", 9F); Padding = new Padding(0);
        LoadSettings();
        BuildShell();
        ApplySettingsToControls();
        RefreshProfileUI();
    }

    private void BuildShell()
    {
        var shell = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new Padding(0), Padding = new Padding(0) };
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        var sidebar = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(9, 11, 16), Padding = new Padding(18, 22, 14, 16) };
        var sideLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 8, Margin = new Padding(0) };
        sideLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));
        for (int i = 1; i < 6; i++) sideLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        sideLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        sideLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
        var logo = new Label { Text = "DEVILS\nFPS", Font = new Font("Segoe UI", 21, FontStyle.Bold), ForeColor = Accent, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
        sideLayout.Controls.Add(logo, 0, 0);
        sideLayout.Controls.Add(NavButton("  PLAY", 0), 0, 1);
        sideLayout.Controls.Add(NavButton("  MODPACKS", 1), 0, 2);
        sideLayout.Controls.Add(NavButton("  SETTINGS", 2), 0, 3);
        sideLayout.Controls.Add(NavButton("  ABOUT", 3), 0, 4);
        sideLayout.Controls.Add(NavButton("  ACCOUNTS / LOGIN", 4), 0, 5);
        sideLayout.Controls.Add(new Label { Text = "MINECRAFT JAVA\n1.21.11 · FABRIC", ForeColor = Muted, Dock = DockStyle.Fill, TextAlign = ContentAlignment.BottomLeft }, 0, 7);
        sidebar.Controls.Add(sideLayout);
        var main = new Panel { Dock = DockStyle.Fill, BackColor = Bg, Padding = new Padding(24, 20, 24, 16) };
        var mainLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Margin = new Padding(0) };
        mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 52)); mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var top = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Margin = new Padding(0) };
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); top.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        top.Controls.Add(new Label { Text = "MINECRAFT CLIENT", ForeColor = Muted, Font = new Font("Segoe UI", 9, FontStyle.Bold), Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        profilePicker.Items.AddRange(profiles.Select(p => p.DisplayName).Cast<object>().ToArray()); profilePicker.SelectedIndex = 0;
        profilePicker.BackColor = Panel2; profilePicker.ForeColor = Color.White; profilePicker.SelectedIndexChanged += (_, _) => SelectProfileByName(profilePicker.SelectedItem?.ToString());
        top.Controls.Add(profilePicker, 1, 0);
        mainLayout.Controls.Add(top, 0, 0);
        BuildPages(); mainLayout.Controls.Add(pages, 0, 1); main.Controls.Add(mainLayout);
        shell.Controls.Add(sidebar, 0, 0); shell.Controls.Add(main, 1, 0); Controls.Add(shell);
    }

    private Button NavButton(string text, int page)
    {
        var b = new Button { Text = text, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(9, 11, 16), ForeColor = Color.FromArgb(220, 223, 232), Font = new Font("Segoe UI", 10, FontStyle.Bold),
            Margin = new Padding(0, 2, 0, 2), Padding = new Padding(8, 0, 0, 0), Cursor = Cursors.Hand, Tag = page };
        b.FlatAppearance.BorderSize = 0; b.Click += (_, _) => pages.SelectedIndex = page; return b;
    }

    private void BuildPages()
    {
        var play = NewPage();
        var playFlow = Flow();
        playFlow.Controls.Add(Heading("WELCOME BACK", 11, Muted));
        playFlow.Controls.Add(Heading("DevilsFPS Client", 27, Color.White));
        playFlow.Controls.Add(Spacer(12));
        playFlow.Controls.Add(Card(new Control[] { playProfile, playDescription, Spacer(8), MakeButton("PLAY SELECTED PROFILE", 210, (_, _) => { if (ApplyToPrism(false)) LaunchPrism(); }), MakeButton("APPLY SETTINGS", 150, (_, _) => ApplyToPrism()), MakeButton("BUILD MODPACK", 150, (_, _) => BuildPack()) }));
        playFlow.Controls.Add(Card(new Control[] { Heading("SELECTED PROFILE CONTENT", 12, Muted), modsSummary }));
        playFlow.Controls.Add(Card(new Control[] { Heading("PERFORMANCE PRESET", 12, Muted), new Label { Text = "Low-effects PvP settings · 6 render · 5 simulation · max brightness · unlimited FPS · VSync off · minimum available particles", AutoSize = true, ForeColor = Color.White, MaximumSize = new Size(650, 0) } }));
        playFlow.Controls.Add(status);
        play.Controls.Add(playFlow); pages.TabPages.Add(play);

        var modpacks = NewPage(); var packFlow = Flow();
        packFlow.Controls.Add(Heading("MODPACK LIBRARY", 24, Color.White));
        packFlow.Controls.Add(new Label { Text = "Choose a profile. You can add more profiles later in the source code.", AutoSize = true, ForeColor = Muted });
        profileList.BackColor = Panel; profileList.ForeColor = Color.White; profileList.Font = new Font("Segoe UI", 12); profileList.ItemHeight = 52;
        profileList.Items.AddRange(profiles.Select(p => p.DisplayName + "\n" + p.Description).Cast<object>().ToArray()); profileList.SelectedIndex = 0;
        profileList.SelectedIndexChanged += (_, _) => { if (profileList.SelectedIndex >= 0) SelectProfile(profiles[profileList.SelectedIndex]); };
        var listHost = new Panel { Height = 180, Width = 720, BackColor = Panel, Padding = new Padding(12) }; listHost.Controls.Add(profileList);
        packFlow.Controls.Add(listHost);
        packFlow.Controls.Add(Card(new Control[] { packProfile, packDescription, Spacer(10), MakeButton("BUILD SELECTED MODPACK", 220, (_, _) => BuildPack()), MakeButton("OPEN PRISM WEBSITE", 170, (_, _) => Process.Start(new ProcessStartInfo("https://prismlauncher.org/") { UseShellExecute = true })) }));
        packFlow.Controls.Add(Card(new Control[] { Heading("TRYANOTHERWAY PROFILE CONTENT", 12, Muted), new Label { Text = "Sodium + Sodium Extra, status effect timer, tier/HUD utilities, View Model, Xaero maps and compatible libraries. Unavailable or unverified uploads are reported by the builder instead of being silently faked.", AutoSize = true, ForeColor = Color.White, MaximumSize = new Size(660, 0) } }));
        modpacks.Controls.Add(packFlow); pages.TabPages.Add(modpacks);

        var settingsPage = NewPage(); var settingsFlow = Flow();
        settingsFlow.Controls.Add(Heading("CLIENT SETTINGS", 24, Color.White));
        settingsFlow.Controls.Add(new Label { Text = "TryAnotherWay defaults are selected automatically for that profile. Changes here are saved locally and can be applied to the matching Prism instance.", AutoSize = true, ForeColor = Muted, MaximumSize = new Size(700, 0) });
        settingsFlow.Controls.Add(Card(new Control[] { Field("Maximum RAM (MiB)", ram), Field("Minimum RAM (MiB)", minRam), Field("Render distance", render), Field("Simulation distance", sim), Field("FPS limit", fps), Field("Resolution preference", resolution), Field("Graphics", graphics), Field("Particles", particles), Field("Clouds", clouds), Field("Entity distance (%)", entity), Field("Brightness (%)", brightness), CheckRow(fullscreen, vsync), Field("Extra JVM arguments", javaArgs), MakeButton("SAVE SETTINGS", 150, (_, _) => SaveSettings()), MakeButton("APPLY TO PRISM", 150, (_, _) => ApplyToPrism()) }));
        settingsPage.Controls.Add(settingsFlow); pages.TabPages.Add(settingsPage);

        var about = NewPage(); var aboutFlow = Flow();
        aboutFlow.Controls.Add(Heading("ABOUT DEVILSFPS", 24, Color.White));
        aboutFlow.Controls.Add(Card(new Control[] { Heading("A configurable community launcher", 15, Color.White), new Label { Text = "This is an original dark, sidebar-based launcher inspired by the general layout of competitive Minecraft clients. It does not copy Lunar Client assets or proprietary code. Sign in through Prism Launcher; this app never asks for Microsoft credentials.", AutoSize = true, ForeColor = Muted, MaximumSize = new Size(680, 0) } }));
        aboutFlow.Controls.Add(Card(new Control[] { Heading("FPS NOTE", 12, Accent), new Label { Text = "Unlimited FPS removes the client cap; it cannot guarantee 200 FPS. The i5-4590T and Intel HD Graphics 4600 may be GPU-limited depending on resolution, server and scene.", AutoSize = true, ForeColor = Color.White, MaximumSize = new Size(680, 0) } }));
        about.Controls.Add(aboutFlow); pages.TabPages.Add(about);

        var accounts = NewPage(); var accountFlow = Flow();
        accountFlow.Controls.Add(Heading("ACCOUNT LOGIN", 24, Color.White));
        accountFlow.Controls.Add(new Label { Text = "Sign in with your Microsoft account through Prism Launcher's official account flow. DevilsFPS never asks for or stores your Microsoft password, session token, or recovery codes.", AutoSize = true, ForeColor = Muted, MaximumSize = new Size(700, 0) });
        accountFlow.Controls.Add(Card(new Control[] {
            Heading("MICROSOFT ACCOUNT", 15, Color.White),
            new Label { Text = "1. Open Prism Launcher\n2. Choose Accounts / Manage Accounts\n3. Add Microsoft account and complete Microsoft's browser sign-in\n4. Return here and press Play Selected Profile", AutoSize = true, ForeColor = Color.White, MaximumSize = new Size(660, 0) },
            Spacer(6),
            MakeButton("OPEN PRISM TO SIGN IN", 220, (_, _) => OpenPrismForAccountLogin()),
            MakeButton("OPEN MICROSOFT ACCOUNT PAGE", 240, (_, _) => Process.Start(new ProcessStartInfo("https://account.microsoft.com/") { UseShellExecute = true }))
        }));
        accountFlow.Controls.Add(Card(new Control[] { Heading("SECURITY", 12, Accent), new Label { Text = "Authentication is handled by Prism Launcher and Microsoft. Do not paste account passwords or Minecraft session tokens into chat, config files, or third-party launchers.", AutoSize = true, ForeColor = Muted, MaximumSize = new Size(680, 0) } }));
        accounts.Controls.Add(accountFlow); pages.TabPages.Add(accounts);
    }

    private TabPage NewPage() => new() { BackColor = Bg, Padding = new Padding(0), Text = "" };
    private static FlowLayoutPanel Flow() => new() { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(2, 6, 12, 12), BackColor = Bg };
    private static Label Heading(string text, float size, Color color) => new() { Text = text, AutoSize = true, ForeColor = color, Font = new Font("Segoe UI", size, FontStyle.Bold), Margin = new Padding(3, 6, 3, 8) };
    private static Control Spacer(int height) => new Panel { Height = height, Width = 20, Margin = new Padding(0) };
    private static Panel Card(IEnumerable<Control> controls)
    {
        var card = new FlowLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Width = 735, FlowDirection = FlowDirection.TopDown, WrapContents = false, BackColor = Panel, Padding = new Padding(18), Margin = new Padding(0, 8, 0, 8) };
        foreach (var c in controls) { c.Margin = new Padding(3, 5, 3, 5); card.Controls.Add(c); }
        return card;
    }
    private static Control Field(string label, Control input)
    {
        var p = new TableLayoutPanel { Width = 660, Height = input is TextBox ? 82 : 42, ColumnCount = 2, RowCount = 1, Margin = new Padding(2, 2, 2, 2) };
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55)); p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        p.Controls.Add(new Label { Text = label, ForeColor = Color.Gainsboro, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        input.Dock = DockStyle.Fill; p.Controls.Add(input, 1, 0); return p;
    }
    private static Control CheckRow(params CheckBox[] checks)
    {
        var row = new FlowLayoutPanel { Width = 660, Height = 36, FlowDirection = FlowDirection.LeftToRight, WrapContents = false };
        foreach (var c in checks) { c.ForeColor = Color.White; c.Margin = new Padding(0, 8, 24, 0); row.Controls.Add(c); } return row;
    }
    private Button MakeButton(string text, int width, EventHandler click)
    {
        var b = new Button { Text = text, Width = width, Height = 38, FlatStyle = FlatStyle.Flat, BackColor = Accent, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold), Margin = new Padding(3, 6, 8, 6), Cursor = Cursors.Hand };
        b.FlatAppearance.BorderSize = 0; b.Click += click; return b;
    }
    private static NumericUpDown Num(int min, int max, int value) => new() { Minimum = min, Maximum = max, Value = value, Width = 130, ThousandsSeparator = true, BackColor = Panel2, ForeColor = Color.White };
    private static ComboBox Combo(params string[] values) { var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 160, BackColor = Panel2, ForeColor = Color.White }; c.Items.AddRange(values); c.SelectedIndex = 0; return c; }

    private void SelectProfileByName(string? name)
    {
        var p = profiles.FirstOrDefault(x => x.DisplayName == name); if (p != null) SelectProfile(p);
    }
    private void SelectProfile(ModpackProfile profile)
    {
        if (selectedProfile.Id != profile.Id)
        {
            Collect(); File.WriteAllText(SettingsPath, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
            selectedProfile = profile; LoadSettings(); ApplySettingsToControls();
        }
        selectedProfile = profile; RefreshProfileUI();
        int index = profiles.FindIndex(x => x.Id == profile.Id);
        if (profilePicker.SelectedIndex != index) profilePicker.SelectedIndex = index;
        if (profileList.SelectedIndex != index) profileList.SelectedIndex = index;
    }
    private static Settings TryAnotherWayDefaults() => new() { Ram = 3072, MinRam = 512, RenderDistance = 6, SimulationDistance = 5, FpsCap = 260, Resolution = "Native", Fullscreen = false, Graphics = "Fast", Particles = "Minimal", Clouds = "Off", EntityDistance = 50, Brightness = 1.0, Vsync = false, ExtraJavaArgs = "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=50" };
    private static Settings CompetitiveDefaults() => new() { Ram = 3072, MinRam = 512, RenderDistance = 6, SimulationDistance = 4, FpsCap = 200, Resolution = "Native", Fullscreen = false, Graphics = "Fast", Particles = "Minimal", Clouds = "Off", EntityDistance = 50, Brightness = 1.0, Vsync = false, ExtraJavaArgs = "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=50" };
    private Settings DefaultsForSelectedProfile() => selectedProfile.Id == "TryAnotherWay" ? TryAnotherWayDefaults() : CompetitiveDefaults();
    private void RefreshProfileUI()
    {
        playProfile.Text = selectedProfile.DisplayName; playDescription.Text = selectedProfile.Description;
        packProfile.Text = selectedProfile.DisplayName; packDescription.Text = selectedProfile.Description;
        modsSummary.Text = selectedProfile.Id == "TryAnotherWay"
            ? "Includes compatible requested PvP/HUD mods: Sodium Extra, Status Effect Timer, Tier Tagger, Tiers, TotemCounter, UI Utils, uku's Armor HUD, View Model, Waypoints Plus, Xaero's Minimap and World Map, plus required libraries."
            : "Includes compatible performance mods such as Sodium, Lithium, FerriteCore, ImmediatelyFast, EntityCulling and Dynamic FPS, plus Fabric API and utility mods.";
    }
    private void LoadSettings()
    {
        try { if (File.Exists(SettingsPath)) settings = JsonSerializer.Deserialize<Settings>(File.ReadAllText(SettingsPath)) ?? DefaultsForSelectedProfile(); else settings = DefaultsForSelectedProfile(); } catch { settings = DefaultsForSelectedProfile(); }
    }
    private void ApplySettingsToControls()
    {
        ram.Value = Clamp(settings.Ram, ram); minRam.Value = Clamp(settings.MinRam, minRam); render.Value = Clamp(settings.RenderDistance, render); sim.Value = Clamp(settings.SimulationDistance, sim); entity.Value = Clamp(settings.EntityDistance, entity); brightness.Value = Math.Clamp((decimal)(settings.Brightness * 100), brightness.Minimum, brightness.Maximum);
        fps.SelectedItem = settings.FpsCap >= 260 ? "Unlimited" : settings.FpsCap.ToString(); if (fps.SelectedIndex < 0) fps.SelectedItem = "Unlimited";
        resolution.SelectedItem = settings.Resolution; if (resolution.SelectedIndex < 0) resolution.SelectedItem = "Native";
        graphics.SelectedItem = settings.Graphics; particles.SelectedItem = settings.Particles; clouds.SelectedItem = settings.Clouds;
        fullscreen.Checked = settings.Fullscreen; vsync.Checked = settings.Vsync; javaArgs.Text = settings.ExtraJavaArgs;
    }
    private static decimal Clamp(int value, NumericUpDown control) => Math.Min(control.Maximum, Math.Max(control.Minimum, value));
    private void Collect() => settings = new Settings { Ram=(int)ram.Value, MinRam=Math.Min((int)minRam.Value,(int)ram.Value), RenderDistance=(int)render.Value, SimulationDistance=(int)sim.Value, FpsCap=fps.SelectedItem?.ToString()=="Unlimited"?260:int.Parse(fps.SelectedItem?.ToString()??"200"), Resolution=resolution.SelectedItem?.ToString()??"Native", Fullscreen=fullscreen.Checked, Graphics=graphics.SelectedItem?.ToString()??"Fast", Particles=particles.SelectedItem?.ToString()??"Minimal", Clouds=clouds.SelectedItem?.ToString()??"Off", EntityDistance=(int)entity.Value, Brightness=(double)brightness.Value/100.0, Vsync=vsync.Checked, ExtraJavaArgs=javaArgs.Text };
    private void SaveSettings()
    {
        Collect(); File.WriteAllText(SettingsPath, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true })); status.Text = "Settings saved locally for " + selectedProfile.DisplayName + ".";
    }
    private bool ApplyToPrism(bool showMessage = true)
    {
        try
        {
            Collect(); File.WriteAllText(SettingsPath, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true })); var instance = FindInstance();
            if (instance is null) { status.Text = "Prism instance not found. Build/import the selected .mrpack first."; if (showMessage) MessageBox.Show(status.Text, "DevilsFPS"); return false; }
            var cfg = Path.Combine(instance, "instance.cfg"); if (!File.Exists(cfg)) throw new FileNotFoundException("instance.cfg not found", cfg);
            var lines = File.ReadAllLines(cfg).ToList(); SetCfg(lines, "OverrideMemory", "true"); SetCfg(lines, "MinMemAlloc", settings.MinRam.ToString()); SetCfg(lines, "MaxMemAlloc", settings.Ram.ToString()); SetCfg(lines, "OverrideJavaArgs", "true"); SetCfg(lines, "JavaArgs", settings.ExtraJavaArgs);
            File.WriteAllLines(cfg, lines);
            var options = Path.Combine(instance, ".minecraft", "options.txt"); if (!File.Exists(options)) options = Path.Combine(instance, "options.txt");
            if (File.Exists(options)) ApplyOptions(options);
            status.Text = "Applied settings to " + selectedProfile.DisplayName + "."; if (showMessage) MessageBox.Show(status.Text, "DevilsFPS"); return true;
        }
        catch (Exception ex) { status.Text = "Apply failed: " + ex.Message; if (showMessage) MessageBox.Show(ex.Message, "DevilsFPS error"); return false; }
    }
    private static void SetCfg(List<string> lines, string key, string value)
    {
        int i = lines.FindIndex(x => x.StartsWith(key + "=", StringComparison.Ordinal)); string entry = key + "=" + value;
        if (i >= 0) lines[i] = entry; else lines.Add(entry);
    }
    private void ApplyOptions(string path)
    {
        var lines = File.ReadAllLines(path).ToList(); var map = new Dictionary<string,string> {
            ["renderDistance"] = settings.RenderDistance.ToString(), ["simulationDistance"] = settings.SimulationDistance.ToString(), ["maxFps"] = settings.FpsCap.ToString(),
            ["enableVsync"] = settings.Vsync.ToString().ToLowerInvariant(), ["fullscreen"] = settings.Fullscreen.ToString().ToLowerInvariant(), ["gamma"] = settings.Brightness.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture),
            ["entityDistanceScaling"] = (settings.EntityDistance / 100.0).ToString(System.Globalization.CultureInfo.InvariantCulture),
            ["clouds"] = settings.Clouds == "Off" ? "0" : settings.Clouds == "Fast" ? "1" : "2",
            ["particles"] = settings.Particles == "Minimal" ? "2" : settings.Particles == "Decreased" ? "1" : "0", ["graphicsMode"] = settings.Graphics == "Fast" ? "0" : "1" };
        foreach (var kv in map) { int i = lines.FindIndex(x => x.StartsWith(kv.Key + ":", StringComparison.Ordinal)); string entry = kv.Key + ":" + kv.Value; if (i >= 0) lines[i] = entry; else lines.Add(entry); }
        File.WriteAllLines(path, lines);
    }
    private string? FindInstance()
    {
        var roots = new[] { Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "PrismLauncher", "instances"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PrismLauncher", "instances"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Prism Launcher", "instances") };
        foreach (var root in roots) { var path = Path.Combine(root, selectedProfile.InstanceName); if (Directory.Exists(path)) return path; }
        using var dlg = new FolderBrowserDialog { Description = "Select the Prism instances folder containing " + selectedProfile.InstanceName };
        if (dlg.ShowDialog(this) == DialogResult.OK) { var path = Path.Combine(dlg.SelectedPath, selectedProfile.InstanceName); if (Directory.Exists(path)) return path; }
        return null;
    }
    private void OpenPrismForAccountLogin()
    {
        var candidates = new[] { Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "PrismLauncher", "prismlauncher.exe"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PrismLauncher", "prismlauncher.exe"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "PrismLauncher", "prismlauncher.exe"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Prism Launcher", "prismlauncher.exe") };
        var exe = candidates.FirstOrDefault(File.Exists);
        if (exe is null) { using var dlg = new OpenFileDialog { Title = "Locate Prism Launcher", Filter = "Prism Launcher|prismlauncher.exe|Executable (*.exe)|*.exe" }; if (dlg.ShowDialog(this) != DialogResult.OK) return; exe = dlg.FileName; }
        Process.Start(new ProcessStartInfo(exe) { UseShellExecute = true });
        status.Text = "Prism opened. Sign in using Accounts / Manage Accounts inside Prism.";
        MessageBox.Show("Prism Launcher is open. In Prism, open Accounts / Manage Accounts, add a Microsoft account, and finish sign-in in Microsoft's browser flow. DevilsFPS does not collect your password.", "Microsoft account sign-in", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void LaunchPrism()
    {
        var candidates = new[] { Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "PrismLauncher", "prismlauncher.exe"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PrismLauncher", "prismlauncher.exe"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "PrismLauncher", "prismlauncher.exe"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Prism Launcher", "prismlauncher.exe") };
        var exe = candidates.FirstOrDefault(File.Exists);
        if (exe is null) { using var dlg = new OpenFileDialog { Title = "Locate Prism Launcher", Filter = "Prism Launcher|prismlauncher.exe|Executable (*.exe)|*.exe" }; if (dlg.ShowDialog(this) == DialogResult.OK) exe = dlg.FileName; }
        if (exe is null) return;
        Process.Start(new ProcessStartInfo(exe, "--launch \"" + selectedProfile.InstanceName + "\"") { UseShellExecute = true }); status.Text = "Requested Prism to launch " + selectedProfile.DisplayName + ".";
    }
    private void BuildPack()
    {
        var script = Path.Combine(AppContext.BaseDirectory, "scripts", "Build-DevilsFPS-Pack.ps1");
        if (!File.Exists(script)) { MessageBox.Show("The modpack builder script was not found. Download the source repository or use scripts/Build-DevilsFPS-Pack.ps1.", "DevilsFPS"); return; }
        var args = "-NoProfile -ExecutionPolicy Bypass -File \"" + script + "\" -Profile " + selectedProfile.Id;
        Process.Start(new ProcessStartInfo("powershell.exe", args) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(script)! });
        status.Text = "Started builder for " + selectedProfile.DisplayName + ". Check the builder window for compatible downloads/skips.";
    }
}

