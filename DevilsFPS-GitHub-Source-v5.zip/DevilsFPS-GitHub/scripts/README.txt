DevilsFPS Modpack Builder

Open PowerShell in this folder and run:
  .\Build-DevilsFPS-Pack.ps1 -Profile TryAnotherWay
or:
  .\Build-DevilsFPS-Pack.ps1 -Profile DevilsFPS

Requires internet access. The builder queries Modrinth and Fabric metadata for Minecraft Java 1.21.11 and writes the .mrpack to this folder's output directory. It prints any projects it could not include. Import the resulting .mrpack into Prism Launcher.

TryAnotherWay defaults: render 6, simulation 5, maximum brightness, unlimited FPS, VSync off, minimal particles, clouds off, Fast graphics, native resolution preference.

Optional local files:
  - Put extra Fabric mod .jar files in local-mods\
  - Put resource-pack .zip files in local-resourcepacks\
The builder copies these into the modpack overrides, skips duplicate local Sodium JARs, and skips resource packs with xray in the filename. Check local files are trusted and compatible before adding them.
