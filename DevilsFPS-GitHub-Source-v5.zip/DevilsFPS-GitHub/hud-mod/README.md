# DevilsFPS HUD (Fabric 1.21.11)

A lightweight client-side HUD mod. Press **Right Shift** in-game to open the module menu. Settings persist in `.minecraft/config/devilsfps-hud.json`.

## Module toggles

FPS, own ping, connected server address, coordinates, keystrokes, armor status, held item, held-item durability, potion effects/timers, sprint status, CPS, health, hunger, facing/direction, biome, world time, movement speed, and a TPS indicator. HUD scale can be adjusted; use **Reset position** to return the overlay to the top-left.

## Honest TPS limitation

The client cannot know a remote server's exact TPS from ordinary client data. This build deliberately displays `TPS -- (server support required)` instead of inventing a number. Exact TPS requires server-side plugin/mod support or a server-provided command/API. The indicator can be hidden in the module menu.

## Install

1. Install Minecraft Java 1.21.11, Fabric Loader, and Fabric API for 1.21.11.
2. Copy `devilsfps-hud-0.1.0.jar` into that instance's `mods` folder.
3. Start the game and press Right Shift.

## Performance notes

The HUD avoids polling expensive world/entity lists. For FPS, pair it with compatible Sodium, Lithium, FerriteCore, ImmediatelyFast, EntityCulling and Dynamic FPS releases where available. Suggested baseline: render distance 6, simulation distance 5, particles Minimal, clouds off, graphics Fast, VSync off and FPS cap Unlimited. No client mod can guarantee a particular FPS on every machine; the i5-4590T / HD Graphics 4600 is a significant limit. This HUD does not alter server TPS or disable normal gameplay mechanics.


## Built-in Inventory HUD+ preview

The HUD mod includes a lightweight inventory preview (not a separate third-party Inventory HUD+ JAR). Toggle **Inventory HUD+ Preview** in the Right Shift module menu. It renders the three main inventory rows and hotbar with item icons and stack counts in a compact bottom-right panel. The setting is saved in `config/devilsfps-hud.json`.
