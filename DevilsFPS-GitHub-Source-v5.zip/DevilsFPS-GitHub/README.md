# DevilsFPS Client — GitHub-buildable source

An original dark, sidebar-style Windows launcher for Minecraft Java 1.21.11 / Fabric. It is inspired by the general layout of competitive Minecraft launchers, but does not use Lunar Client assets or proprietary code. Target machine: Intel Core i5-4590T, Intel HD Graphics 4600, 8 GB RAM.

## Build on GitHub (no local SDK required)

1. Create a GitHub repository and upload the contents of this folder (include the hidden `.github` directory).
2. Open **Actions** and enable workflows if prompted.
3. Push to `main`/`master`, or choose **Build DevilsFPS for Windows** → **Run workflow**.
4. Open the completed run and download the **DevilsFPS-Windows-x64** artifact. Extract it and run `DevilsFPS.exe` on Windows 10/11 x64.
5. To create a GitHub Release, push a tag such as `v0.2.0`; the workflow attaches the ZIP to that release.

GitHub Actions builds a self-contained .NET 8 Windows x64 executable. This repository does not include a prebuilt executable, and the app has not been verified by a successful build until the workflow completes.

## Launcher features

- Sidebar pages: Play, Modpacks, Settings, Accounts / Login and About
- Selectable profiles: **TryAnotherWay's Mods** and **DevilsFPS Competitive**
- Per-profile RAM, JVM and video settings saved separately
- Render/simulation distance, FPS cap (including Unlimited), resolution preference, graphics, particles, clouds, entity distance, brightness, fullscreen and VSync controls
- Applies supported RAM/JVM/video settings to the matching Prism Launcher instance and can ask Prism to launch it
- Modpack builder resolves compatible public Fabric files at build time through Modrinth and uses the official Fabric metadata service
- Companion Fabric 1.21.11 in-game HUD mod with a Right Shift module menu for FPS, own ping, server address, coordinates, keystrokes, armor, potion effects, sprint state, CPS, health, hunger, direction, biome, world time, movement speed, held item, durability and HUD scaling
- Microsoft sign-in stays inside Prism Launcher; this app does not collect credentials

## Build a modpack

Run in Windows PowerShell with internet access:

```powershell
# TryAnotherWay's Mods profile
.\scripts\Build-DevilsFPS-Pack.ps1 -Profile TryAnotherWay

# Performance-first profile
.\scripts\Build-DevilsFPS-Pack.ps1 -Profile DevilsFPS
```

The `.mrpack` files are created in `scripts/output/`. The GitHub-built launcher ZIP also contains the compiled HUD JAR under `mods/`; the builder automatically includes it in the profile when run from that ZIP. If you run the builder from source, build `hud-mod` first or copy the JAR into `scripts/local-mods/`. Import the selected `.mrpack` into Prism Launcher, sign in there, and launch the instance once. Then select the matching profile in DevilsFPS and use **Apply Settings**. In-game, press **Right Shift** to open the module menu.

### TryAnotherWay profile defaults

- Render distance: 6 chunks
- Simulation distance: 5 chunks
- Brightness: maximum (`gamma:1.0`)
- FPS: Unlimited (`maxFps:260`)
- VSync: off; particles: Minimal; clouds: Off; graphics: Fast
- Resolution: Native / no forced custom resolution

The builder attempts to include the requested public projects: Sodium, Sodium Extra, Status Effect Timer, SuperMartijn642's Config Lib, Text Placeholder API, Tier Tagger, Tiers, TotemCounter, UI Utils, uku's Armor HUD, ukulib, Variants-CIT, View Model, WalksyLib, Xaero's Minimap and Xaero's World Map. It also checks compatible Fabric performance/API dependencies. Actual inclusion depends on what each project declares compatible with Minecraft 1.21.11 at build time; review the PowerShell output and `overrides/PROFILE-README.txt` for anything skipped.

Some items in the list were marked **Uploaded** or **Unknown** rather than linked to a public project (for example, Theone's Eating Animation Pack and Waypoints Plus). The builder cannot fetch those from filenames alone. Place the actual trusted `.jar` files in `scripts/local-mods/` and resource-pack `.zip` files in `scripts/local-resourcepacks/`, then rebuild; local files are included as overrides. Sodium duplicates are skipped because Sodium is already resolved from Modrinth. Xray-named resource packs are intentionally excluded from the fair-play PvP profile. The builder cannot confirm the compatibility or safety of locally supplied files.

## HUD / TPS limitation

The HUD displays your own ping and connected server address. Modules include FPS, ping, server address, coordinates, keystrokes, CPS, armor, held item/durability, potion effects, sprint, health, hunger, facing, biome, world time and movement speed. The launcher has an Accounts / Login page that opens Prism for Microsoft sign-in; DevilsFPS never collects account credentials. Exact remote server TPS cannot be read reliably from a normal client unless the server exposes it through a plugin/mod or API. The HUD deliberately displays `TPS -- (server support required)` rather than fabricating a number. CPS is client-side click counting.

## Hardware note

The Minecraft `maxFps:260` option corresponds to the game’s highest/unlimited slider setting; it does not guarantee 200 FPS. The Intel HD Graphics 4600 is an older integrated GPU, so performance varies with world, server, drivers, thermals, resolution and memory bandwidth. Start with 3072 MiB max RAM on an 8 GB system and do not allocate all system memory to Minecraft.

## Important limitations

- Prism Launcher must be installed and the instance imported first. The expected instance names are `TryAnotherWay-1.21.11` and `DevilsFPS-1.21.11`.
- The resolution choice is a preference field; Native means the launcher does not force a custom display resolution. Change the actual display mode in Minecraft if needed.
- The builder only adds versions reported compatible by Modrinth/Fabric metadata. It does not claim to bundle every filename from the supplied list if the source file is private, missing, or incompatible.
- No aim assist, reach, autoclicker, x-ray or other gameplay cheats are included.


### Inventory HUD+
The bundled Fabric HUD mod has a built-in Inventory HUD+ style preview: enable/disable it in the Right Shift menu to show the three inventory rows and hotbar, including item icons and stack counts. It is an in-house lightweight feature, not the third-party Inventory HUD+ project.
