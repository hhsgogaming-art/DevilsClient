Optional resource-pack .zip files go here. Xray-named packs are skipped by the builder for the fair-play PvP profile.
Only add files you trust.
