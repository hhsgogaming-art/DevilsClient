package com.devilsfps.hud;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;

public final class DevilsFpsHud implements ClientModInitializer {
    static final Minecraft MC = Minecraft.getInstance();
    static ModuleSettings settings;
    private static KeyMapping menuKey;
    private static int leftCps;
    private static int rightCps;
    private static boolean wasLeftDown;
    private static boolean wasRightDown;
    private static final Deque<Long> LEFT_CLICKS = new ArrayDeque<>();
    private static final Deque<Long> RIGHT_CLICKS = new ArrayDeque<>();

    @Override public void onInitializeClient() {
        settings = ModuleSettings.load();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.devilsfps.open_modules", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.consumeClick()) client.setScreen(new ModuleScreen());
            long now = System.currentTimeMillis();
            boolean leftDown = GLFW.glfwGetMouseButton(client.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            boolean rightDown = GLFW.glfwGetMouseButton(client.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
            if (leftDown && !wasLeftDown) LEFT_CLICKS.addLast(now);
            if (rightDown && !wasRightDown) RIGHT_CLICKS.addLast(now);
            wasLeftDown = leftDown; wasRightDown = rightDown;
            trim(LEFT_CLICKS, now); trim(RIGHT_CLICKS, now);
            leftCps = LEFT_CLICKS.size(); rightCps = RIGHT_CLICKS.size();
        });
        HudElementRegistry.addLast(ResourceLocation.fromNamespaceAndPath("devilsfps_hud", "overlay"),
                (graphics, deltaTracker) -> renderHud(graphics));
    }

    private static void trim(Deque<Long> clicks, long now) { while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.removeFirst(); }

    private static void renderHud(GuiGraphics g) {
        if (MC.player == null || MC.level == null || MC.options.hideGui) return;
        int y = settings.hudY;
        int color = 0xFFF4F5F7;
        int scale = Math.max(50, Math.min(150, settings.scale));
        int x = Math.max(0, settings.hudX);
        g.pose().pushMatrix();
        g.pose().scale(scale / 100.0f, scale / 100.0f);
        if (settings.fps) y = line(g, "FPS " + MC.getFps(), x, y, color);
        if (settings.ping) {
            int ping = -1;
            if (MC.getConnection() != null && MC.player != null && MC.getConnection().getPlayerInfo(MC.player.getUUID()) != null)
                ping = MC.getConnection().getPlayerInfo(MC.player.getUUID()).getLatency();
            y = line(g, ping >= 0 ? "PING " + ping + " ms" : "PING --", x, y, color);
        }
        if (settings.serverAddress) {
            String address = MC.getCurrentServer() == null ? "SINGLEPLAYER" : MC.getCurrentServer().ip;
            y = line(g, "SERVER " + address, x, y, color);
        }
        if (settings.coordinates) {
            var p = MC.player;
            y = line(g, String.format(Locale.ROOT, "XYZ %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ()), x, y, color);
        }
        if (settings.sprint) y = line(g, "SPRINT " + (MC.player.isSprinting() ? "ON" : "OFF"), x, y, color);
        if (settings.health) y = line(g, String.format(Locale.ROOT, "HEALTH %.1f / %.1f", MC.player.getHealth(), MC.player.getMaxHealth()), x, y, color);
        if (settings.hunger) y = line(g, "HUNGER " + MC.player.getFoodData().getFoodLevel() + " / 20", x, y, color);
        if (settings.direction) y = line(g, "FACING " + MC.player.getDirection().getName().toUpperCase(Locale.ROOT), x, y, color);
        if (settings.biome) y = line(g, "BIOME " + MC.level.getBiome(MC.player.blockPosition()).value().getName().getString(), x, y, color);
        if (settings.worldTime) { long time = Math.floorMod(MC.level.getDayTime(), 24000L); y = line(g, String.format(Locale.ROOT, "WORLD TIME %02d:%02d", ((time + 6000) / 1000) % 24, (time % 1000) * 60 / 1000), x, y, color); }
        if (settings.speed) y = line(g, String.format(Locale.ROOT, "SPEED %.2f m/s", MC.player.getDeltaMovement().horizontalDistance() * 20.0), x, y, color);
        if (settings.heldItem) y = line(g, "HELD " + MC.player.getMainHandItem().getHoverName().getString(), x, y, color);
        if (settings.itemDurability) { var held = MC.player.getMainHandItem(); if (!held.isEmpty() && held.getMaxDamage() > 0) y = line(g, "DURABILITY " + Math.max(0, held.getMaxDamage() - held.getDamageValue()) + " / " + held.getMaxDamage(), x, y, color); }
        if (settings.tpsEstimate) y = line(g, "TPS -- (server support required)", x, y, 0xFFFFD166);
        if (settings.keystrokes) {
            String keys = keyDown(GLFW.GLFW_KEY_W, "W") + " " + keyDown(GLFW.GLFW_KEY_A, "A") + " " + keyDown(GLFW.GLFW_KEY_S, "S") + " " + keyDown(GLFW.GLFW_KEY_D, "D")
                    + "   " + keyDown(GLFW.GLFW_KEY_SPACE, "JUMP") + "   " + keyDown(GLFW.GLFW_KEY_LEFT_SHIFT, "SHIFT");
            line(g, keys, x, y + 2, color);
        }
        if (settings.showCps) line(g, "CPS L " + leftCps + " / R " + rightCps, x, y + 14, color);
        if (settings.armor) {
            StringBuilder armor = new StringBuilder("ARMOR ");
            for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                var item = MC.player.getItemBySlot(slot);
                if (item.isEmpty()) armor.append("-- ");
                else if (item.getMaxDamage() > 0) armor.append(Math.max(0, item.getMaxDamage() - item.getDamageValue())).append(' ');
                else armor.append("OK ");
            }
            line(g, armor.toString(), x, y + 28, color);
        }
        if (settings.potionEffects) {
            int ey = 6;
            for (MobEffectInstance effect : MC.player.getActiveEffects()) {
                String name = effect.getEffect().value().getDisplayName().getString();
                String time = effect.isInfiniteDuration() ? "∞" : String.format(Locale.ROOT, "%d:%02d", effect.getDuration() / 1200, (effect.getDuration() / 20) % 60);
                line(g, name + " " + time, Math.max(6, MC.getWindow().getGuiScaledWidth() - 130), ey, color); ey += 11;
            }
        }
        if (settings.inventoryHud) renderInventoryHud(g);
        g.pose().popMatrix();
    }


    /** Lightweight built-in Inventory HUD+ preview: main inventory grid plus hotbar. */
    private static void renderInventoryHud(GuiGraphics g) {
        var inventory = MC.player.getInventory();
        final int slot = 18;
        final int cols = 9;
        final int rows = 4; // three inventory rows plus hotbar
        final int panelWidth = cols * slot + 8;
        final int panelHeight = rows * slot + 24;
        final int x = Math.max(4, MC.getWindow().getGuiScaledWidth() - panelWidth - 8);
        final int y = Math.max(4, MC.getWindow().getGuiScaledHeight() - panelHeight - 8);
        g.fill(x, y, x + panelWidth, y + panelHeight, 0xB8181B24);
        g.fill(x, y, x + panelWidth, y + 1, 0xFFFF415F);
        g.drawString(MC.font, Component.literal("INVENTORY"), x + 4, y + 4, 0xFFF4F5F7, false);
        int gridY = y + 17;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < cols; col++) {
                int invIndex = 9 + row * cols + col;
                drawInventorySlot(g, inventory.getItem(invIndex), x + 4 + col * slot, gridY + row * slot);
            }
        }
        int hotbarY = gridY + 3 * slot + 3;
        for (int col = 0; col < cols; col++) {
            drawInventorySlot(g, inventory.getItem(col), x + 4 + col * slot, hotbarY);
        }
    }

    private static void drawInventorySlot(GuiGraphics g, net.minecraft.world.item.ItemStack stack, int x, int y) {
        g.fill(x, y, x + 17, y + 17, 0xA03B3F4B);
        g.fill(x, y, x + 17, y + 1, 0x604F5360);
        if (!stack.isEmpty()) {
            g.renderItem(stack, x + 1, y + 1);
            g.renderItemDecorations(MC.font, stack, x + 1, y + 1);
        }
    }

    private static int line(GuiGraphics g, String text, int x, int y, int color) {
        g.drawString(MC.font, Component.literal(text), x, y, color, true);
        return y + 11;
    }
    private static String keyDown(int key, String label) {
        boolean down = GLFW.glfwGetKey(MC.getWindow().getWindow(), key) == GLFW.GLFW_PRESS;
        return down ? "[" + label + "]" : label;
    }
}
