DEVILS FPS — CONFIGURABLE COMPETITIVE CLIENT KIT
Minecraft Java Edition 1.21.11 | Windows | Intel HD Graphics 4600 / 8 GB RAM

WHAT THIS IS
A configurable launcher front-end and a builder that creates a Prism-importable
Modrinth pack using official Modrinth/Fabric metadata at build time. It does not
bundle Minecraft itself or bypass Microsoft authentication.

BUILD THE MODPACK
1. Keep an internet connection available.
2. Run Build-DevilsFPS-Pack.ps1 from PowerShell.
3. It queries Modrinth for stable Fabric releases compatible with Minecraft 1.21.11
   and creates output\DevilsFPS-Competitive-1.21.11.mrpack.
4. Install Prism Launcher from https://prismlauncher.org/ and sign in with your own
   Microsoft account.
5. In Prism: Add Instance > Import, select the .mrpack file, and name the instance
   exactly DevilsFPS-1.21.11.
6. Launch the instance once, then close Minecraft.
7. Double-click Start-DevilsFPS.bat. Choose your RAM, render/simulation distance,
   FPS cap, resolution preference, fullscreen, graphics, particles, clouds, entity
   distance and advanced JVM arguments. Save + Apply or Apply + Launch.

CONFIGURATION
The launcher stores its preferences in DevilsFPS-settings.json. It writes RAM and
JVM settings to Prism's instance.cfg and common video options to options.txt when
those files exist. The resolution selector is a preference reminder; Minecraft
resolution is controlled by your display/fullscreen mode and may need to be set
in-game. The FPS cap option writes a Minecraft maxFps value; Unlimited is represented
by a high cap. Check the resulting settings in-game after updating Minecraft/mods.

STARTING SETTINGS FOR INTEL HD 4600 + 8 GB RAM
- 3072 MiB maximum RAM, 512 MiB minimum RAM
- 1280x720, render distance 6, simulation distance 4
- Fast graphics, minimal particles, clouds off, entity distance 50%
- VSync off; try a 120/144/200 FPS cap and compare frame-time stability
- Close browsers and overlays during competitive play; keep drivers and Windows current

IMPORTANT
200 FPS is not guaranteed. Intel HD Graphics 4600 is an older integrated GPU; actual
FPS depends on world, effects, server, resolution, RAM channel configuration, drivers,
and thermal/power limits. If 200 FPS is unstable, use a lower cap for steadier frame
pacing. Do not allocate all 8 GB of system RAM to Minecraft.

This is not Lunar Client and has no proprietary Lunar features. It is a lightweight,
open-mod-based alternative with a custom configurable launcher front-end. Only use
client-side mods allowed by the server. It excludes aim assist, reach hacks, autoclickers,
x-ray, and other gameplay cheats. If no stable compatible mod release exists at build
time, the builder skips it and reports that fact.
