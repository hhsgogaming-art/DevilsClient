package com.devilsfps.hud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

final class ModuleSettings {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("devilsfps-hud.json");

    boolean fps = true;
    boolean ping = true;
    boolean serverAddress = true;
    boolean coordinates = true;
    boolean keystrokes = true;
    boolean armor = true;
    boolean potionEffects = true;
    boolean sprint = true;
    boolean tpsEstimate = true;
    boolean showCps = true;
    boolean health = true;
    boolean hunger = true;
    boolean direction = true;
    boolean biome = false;
    boolean worldTime = true;
    boolean speed = false;
    boolean heldItem = true;
    boolean itemDurability = true;
    boolean inventoryHud = true;
    int scale = 100;
    int hudX = 6;
    int hudY = 6;

    static ModuleSettings load() {
        try {
            if (Files.exists(FILE)) {
                ModuleSettings settings = GSON.fromJson(Files.readString(FILE), ModuleSettings.class);
                if (settings != null) return settings;
            }
        } catch (Exception ignored) { }
        ModuleSettings settings = new ModuleSettings();
        settings.save();
        return settings;
    }

    void save() {
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(this)); }
        catch (IOException e) { System.err.println("DevilsFPS HUD could not save settings: " + e.getMessage()); }
    }
}
